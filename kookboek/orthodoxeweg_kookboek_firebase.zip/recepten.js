// Firebase configuratie (invullen met jouw gegevens)
const firebaseConfig = {
  apiKey: "VUL-HIER-IN",
  authDomain: "VUL-HIER-IN",
  projectId: "VUL-HIER-IN",
  storageBucket: "VUL-HIER-IN",
  messagingSenderId: "VUL-HIER-IN",
  appId: "VUL-HIER-IN"
};

// Firebase initialisatie
firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();

// Formulierverwerking
document.getElementById('receptForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const form = e.target;
  const data = {
    naam: form.naam.value,
    ingredienten: form.ingredienten.value,
    bereiding: form.bereiding.value,
    hoofdtak: form.hoofdtak.value,
    vastenregel: form.vastenregel.value,
    datum: new Date().toISOString()
  };

  db.collection("recepten").add(data)
    .then(() => {
      document.getElementById('status').textContent = "Recept succesvol verzonden!";
      form.reset();
    })
    .catch((error) => {
      document.getElementById('status').textContent = "Fout bij verzenden: " + error;
    });
});
